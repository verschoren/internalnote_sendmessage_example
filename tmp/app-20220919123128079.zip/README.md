# Demo App for sendMessage() for Zendesk Support Apps
.
See the [following article on Internal Note](internalnote.com/ticket-sendmessage-api/) for more info.

![banner](https://user-images.githubusercontent.com/894026/174453252-9131836c-a763-47c5-9a65-274bd0b59ca4.png)
